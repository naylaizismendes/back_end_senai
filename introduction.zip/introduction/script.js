alert("oLA MUNDO");
console.log("ola mundo de novo");

const nota1 = 5;
const nota2 = 6.7;
console.log(nota1);
console.log(nota2)

const media = (nota1 + nota2) / 2;
console.log(media)

//shift alt f 
if (media >= 7) {
    console.log('Aprovado')
}
if (media < 7) {
    console.log('Reprovado')
}
console.log(media)