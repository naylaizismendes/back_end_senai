alert('OLA')
console.log('to aqui')

//logica de proggramacao
// text
// 132- > numbe
//true/false -. boolean

//const -> sao constantes  
// lety /var variaveis map constates )podem mudar
const nota1 = 10;
const nota2 = 5;
const meuNome = 'Ze da manga';
console.log(meuNome)
const idade= '33';

console.log(meuNome,idade)



const num1= 