//exec1
// const num1 = 60;
// const num2 = 30;

// const soma = num1 + num2;
// const subtracao = num1 - num2;
// const multilicao = num1 * num2;
// const divisao = num1 / num2;

// console.log(soma)
// console.log(subtracao)
// console.log(multilicao)
// console.log(divisao)


// if (soma % 2 == 0){
//     console.log('e PAR')
// }else{
//     console.log('e impar')
// }


///// exec 2

// motivo  -> utilizamos a i
// const number1=50
// const number2="50";

// if(number1 == number2){
//    console.log('igualdade de valores ')
// }
// if(number1 === number2){
//     console.log('igualdade e diferente nesse casoo valores e o tipo de dado( string e number)')
// }
// if(number1!==number2){
//     console.log('igualdade de valores')
// }

//exec3 

