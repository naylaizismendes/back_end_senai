

//exec1 
/*const nomeCompl= 'Nayla izis mendes ferreira';
const idade=21;
const estudade=true;
console.log(nomeCompl)
console.log(idade)
console.log(estudade)
*/
//execm 2


//motivo do erro constante nao recebe reatribuição
/*
const idade = 21;
const anoNacimento = 2004;
console.log(idade)
console.log(anoNacimento)

*/
//exec 3
/*
const pokemon1 = "Charmander";
const nivel11 = 11;
const status_capturado1 = false;
const pokemon2 = "Pikachu";
const nivel12 = 15;
const status_capturado2 = true;
const pokemon3 = "Bulbasaur"
const nivel13 = 10;
const status_capturado3 = true;
const pokemon4 = "Squirtle"
const nivel14 = 14;
const status_capturado4 = false;

console.log(pokemon1,nivel11,status_capturado1)
console.log(pokemon2,nivel12,status_capturado2)
console.log(pokemon3,nivel13,status_capturado3)
console.log(pokemon4,nivel14,status_capturado4)
*/


//exec4 
/*
let nomeProduto = "Notebook";
let precoProduto = 1222.50;
let disponivelEstoque = false;

console.log(nomeProduto, precoProduto, disponivelEstoque)
*/

//EXEC 5 
let nomeCliente = "Maria "

let precoProduto = 50;

let produtoDisponivel = true;


console.log(nomeCliente,precoProduto,produtoDisponivel)