// = atriuicao
// == comparacao 

//console.log(2==2)
//console.log(2>2)
//console.log(2 >=2)
//console.log(2 < = 2)
// console.log(2 != 2) difereça


//if /else
const numero= 7;
if(numero % 2 == 0){
    console.log('numero par');
}else{
    console.log('numero e impar')
}